const router=require('express').Router()
const regc=require('../controllers/regcontroller')
const multer=require('multer')
const nodemailer=require('nodemailer')
function handlerole(req,res,next){
    if(req.session.role=='pvt'){
        next()
    }else{
        res.send("you dont right to see this page")
    }
}

let storage=multer.diskStorage({
    destination:function(req,file,cb){
        cb(null,'./public/upload')
    },
    filename:function(req,file,cb){
        cb(null, Date.now()+file.originalname)
    }
})

let upload=multer({
    storage:storage,
    limits:{fileSize:1024*1024*4}
})



function handlelogin(req,res,next){
    if(req.session.isAuth){
        next()
    }else{
        res.redirect('/login')
    }
}

router.get('/',handlelogin,regc.homepage)
router.get('/reg',regc.regform)
router.post('/reg',regc.reginsert)
router.get('/login',regc.loginshow)
router.post('/login',regc.logincheck)
router.get('/logout',regc.logout)
router.get('/emailverify/:email',regc.emailverify)
router.get('/profile',handlelogin,regc.porfile)
router.post('/profile',upload.single('img'),regc.profileupdate)
router.get('/testi',handlelogin,handlerole,regc.testi)
router.get('/forgotpassword',regc.forgotshow)
router.post('/forgotpassword',regc.forgotdata)
router.get('/forgotmessage',regc.fortgotmessage)
router.get('/changepassword/:email',regc.forgotlink)
router.post('/forgotpasswordnew/:email',regc.forgotpasswordupdate)
router.get('/changepassword',regc.changepasswordshow)
router.post('/changepassword',regc.changepassword)
router.get('/profiledetails/:id',handlelogin,handlerole,regc.profiledetailsfront)






module.exports=router